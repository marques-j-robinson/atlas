# Notes about vim
A simple document to keep track of useful notes about how to use vim.

## Basic search and Replace
`:%s/foo/bar/g`

## The .
Type `.` in normal mode to repeat last change, this is super useful when doing receptive changes.

## The % key
You can use the % key to jump to a matching opening or closing parenthesis, square bracket or a curly brance.

## Super star and sharp
In normal mode you can use `*` and `#` to search for a word under the cursor.
`*` searches forward for the word, while `#` searches backwards.

## Undo and redo
You can use `u` to undo the last change. `CTRL-R` redoes a change that has been undone. `U` returns the current line to its original state.

## Record
To start recording, press `qa` in the normal mode, this will save your recording in the `a` register. Now do your actions. After you are done, stop recording by issuing `q` in normal mode.

To replay your recording issue `@a` in normal mode.

## Macros
- Press `q` to tell vim you want to record, then press almost any key to tell vim you want to save your recording to that key.
We will use the key `a` for this example. So this command would be `qa`.
- Perform your command.
- Press `q` to end the recording.
- When you want to replay that series of actions, press `@a`.

## Relative Line Number
It is easier to calculate `23 = 23` than it is to calculate `141-118 = 23`.
Relative line number displays line numbers not as absolute line numbers of a text file, but as line numbers relative to your cursor position.

You can get this by adding the following to your .vimrc file:

`set relativenumber`

You can then delete the next 25 lines by using the following vim command:

`25dd`

## Registers
Registers are used to store text when you copy text for pasting.
Computers have multiple registers.
By default, vim uses a register for its stored text that is different from the system's copy stored text.
The following will allow seamless copy/past functionality in vim:

```
set clipboard=unnamed
set clipboard=unnamedplus
```

If you want to delete text without overwriting your register, you can run `"_` before your command, such as:

`"_dd`

to delete a line.

## Markers
Use markers to set places you want to quickly get back to, or to specify a block of text you want to copy or cut.

```
    mk - mark current position (can use a-z)
    'k - move to the mark k
    d'k - delete from current position to mark k
    'a-z - same file
    'A-Z - between files
```
