# Marques' dotfiles

My personal dotfiles

## Usage
    - Clone the repository into `~/.dotfiles`
    - Run `rake install` script to link various files into the home directory
